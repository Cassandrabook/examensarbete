<?php 
    get_header();?>

<main class="contact">

    <div class="contact-container">
            <div class="contact-content">
            <h1 class="contact-title"><?php the_title(); ?></h1>
                    <?php the_content() ?>
                </div>
        </div>
    </div>
    
</main>

    <?php get_footer();
?>